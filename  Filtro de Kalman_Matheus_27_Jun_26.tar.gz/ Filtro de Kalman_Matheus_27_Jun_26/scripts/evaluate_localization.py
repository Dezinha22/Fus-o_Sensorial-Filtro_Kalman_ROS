#!/usr/bin/env python
# -*- coding: utf-8 -*-

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import rospy
import numpy as np
from nav_msgs.msg import Odometry
import tf.transformations as tf_trans
import os
from datetime import datetime
from threading import Lock

class LocalizationEvaluator:
    def __init__(self):
        rospy.init_node('evaluate_localization', anonymous=True)

        self.lock = Lock()
        self.gt_data = {}
        self.filt_data = {}

        rospy.Subscriber('/gt/odom', Odometry, self.gt_callback)
        rospy.Subscriber('/odometry/filtered', Odometry, self.filtered_callback)

        rospy.on_shutdown(self.save_and_plot)
        rospy.loginfo("Nó de avaliação iniciado (modo robusto). Aguardando dados...")

    def gt_callback(self, msg):
        with self.lock:
            self.gt_data[msg.header.stamp.to_nsec()] = msg

    def filtered_callback(self, msg):
        with self.lock:
            self.filt_data[msg.header.stamp.to_nsec()] = msg

    def save_and_plot(self):
        with self.lock:
            if len(self.gt_data) < 10 or len(self.filt_data) < 10:
                rospy.logwarn("Poucos dados coletados.")
                return

            matched_data = []
            gt_times = sorted(self.gt_data.keys())

            for gt_time in gt_times:
                closest_time = min(self.filt_data.keys(), key=lambda x: abs(x - gt_time))

                if abs(closest_time - gt_time) > 500_000_000:  # 500ms de tolerância
                    continue

                gt_msg = self.gt_data[gt_time]
                filt_msg = self.filt_data[closest_time]

                gt_pose = gt_msg.pose.pose
                filt_pose = filt_msg.pose.pose

                dx = gt_pose.position.x - filt_pose.position.x
                dy = gt_pose.position.y - filt_pose.position.y
                position_error = np.sqrt(dx**2 + dy**2)

                gt_yaw = tf_trans.euler_from_quaternion([
                    gt_pose.orientation.x, gt_pose.orientation.y,
                    gt_pose.orientation.z, gt_pose.orientation.w
                ])[2]

                filt_yaw = tf_trans.euler_from_quaternion([
                    filt_pose.orientation.x, filt_pose.orientation.y,
                    filt_pose.orientation.z, filt_pose.orientation.w
                ])[2]

                yaw_error = abs(gt_yaw - filt_yaw)

                matched_data.append({
                    'timestamp': gt_time / 1e9,
                    'gt_x': gt_pose.position.x,
                    'gt_y': gt_pose.position.y,
                    'filt_x': filt_pose.position.x,
                    'filt_y': filt_pose.position.y,
                    'position_error': position_error,
                    'yaw_error': yaw_error
                })

            if len(matched_data) < 10:
                rospy.logwarn("Poucos dados pareados.")
                return

            # === Gerar gráficos e métricas ===
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            results_dir = os.path.join("/home/ros/.ros/results", timestamp)
            os.makedirs(results_dir, exist_ok=True)

            timestamps = np.array([d['timestamp'] for d in matched_data])
            gt_x = np.array([d['gt_x'] for d in matched_data])
            gt_y = np.array([d['gt_y'] for d in matched_data])
            filt_x = np.array([d['filt_x'] for d in matched_data])
            filt_y = np.array([d['filt_y'] for d in matched_data])
            pos_errors = np.array([d['position_error'] for d in matched_data])
            yaw_errors = np.array([d['yaw_error'] for d in matched_data])

            time = timestamps - timestamps[0]

            # Gráfico de Trajetória
            plt.figure(figsize=(11, 9))
            plt.plot(gt_x, gt_y, color='#2ecc71', linewidth=2.5, label='Ground Truth')
            plt.plot(filt_x, filt_y, color='#e74c3c', linewidth=1.8, linestyle='--', label='Filtrada (EKF)')
            plt.plot(gt_x[0], gt_y[0], 'go', markersize=8)
            plt.plot(gt_x[-1], gt_y[-1], 'g^', markersize=8)
            plt.xlabel('Posição X (m)', fontsize=12)
            plt.ylabel('Posição Y (m)', fontsize=12)
            plt.title('Comparação de Trajetória - Filtro de Kalman', fontsize=14, fontweight='bold')
            plt.legend(fontsize=10)
            plt.grid(True, alpha=0.3)
            plt.axis('equal')
            plt.tight_layout()
            plt.savefig(os.path.join(results_dir, 'trajectory.png'), dpi=220)
            plt.close()

            # Gráfico de Erro de Posição
            plt.figure(figsize=(11, 6))
            plt.plot(time, pos_errors, color='#3498db', linewidth=1.8)
            plt.xlabel('Tempo (s)', fontsize=12)
            plt.ylabel('Erro de Posição (m)', fontsize=12)
            plt.title('Erro de Posição ao Longo do Tempo', fontsize=14, fontweight='bold')
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(os.path.join(results_dir, 'position_error.png'), dpi=200)
            plt.close()

            # Gráfico de Erro de Yaw
            plt.figure(figsize=(11, 6))
            plt.plot(time, yaw_errors, color='#9b59b6', linewidth=1.8)
            plt.xlabel('Tempo (s)', fontsize=12)
            plt.ylabel('Erro de Orientação - Yaw (rad)', fontsize=12)
            plt.title('Erro de Orientação ao Longo do Tempo', fontsize=14, fontweight='bold')
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(os.path.join(results_dir, 'yaw_error.png'), dpi=200)
            plt.close()

            # Métricas
            pos_rmse = np.sqrt(np.mean(pos_errors**2))
            pos_mean = np.mean(pos_errors)
            pos_max = np.max(pos_errors)
            pos_std = np.std(pos_errors)
            final_pos_error = pos_errors[-1]

            yaw_rmse = np.sqrt(np.mean(yaw_errors**2))
            yaw_mean = np.mean(yaw_errors)
            yaw_max = np.max(yaw_errors)

            with open(os.path.join(results_dir, "metrics.txt"), "w") as f:
                f.write("=== Métricas de Avaliação - Filtro de Kalman ===\n\n")
                f.write("--- Posição ---\n")
                f.write(f"RMSE Posição:          {pos_rmse:.4f} m\n")
                f.write(f"Erro Médio Posição:    {pos_mean:.4f} m\n")
                f.write(f"Erro Máximo Posição:   {pos_max:.4f} m\n")
                f.write(f"Desvio Padrão Posição: {pos_std:.4f} m\n")
                f.write(f"Erro Final Posição:    {final_pos_error:.4f} m\n\n")
                f.write("--- Orientação (Yaw) ---\n")
                f.write(f"RMSE Orientação (Yaw): {yaw_rmse:.4f} rad\n")
                f.write(f"Erro Médio Yaw:        {yaw_mean:.4f} rad\n")
                f.write(f"Erro Máximo Yaw:       {yaw_max:.4f} rad\n")

            rospy.loginfo(f"Resultados salvos em: {results_dir}")

if __name__ == '__main__':
    try:
        evaluator = LocalizationEvaluator()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
